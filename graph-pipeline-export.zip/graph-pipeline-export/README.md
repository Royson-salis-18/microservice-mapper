# Microservice Dependency Graph — How It's Built

This folder is an isolated, read-only copy of the code that turns a live Docker
host into a service dependency graph (nodes + edges). It's extracted from a
larger observability app so it can be read on its own.

**This is a reading copy, not a runnable package.** The files are verbatim
copies, but they're regrouped into numbered folders by pipeline stage, so the
relative imports inside them won't resolve here. The table at the bottom maps
every file back to its original path.

---

## 1. What the system does

Given nothing but SSH access to a machine running Docker, it produces:

- **Nodes** — one per running container, named and classified (gateway,
  database, queue, …)
- **Edges** — dependencies between those services, each tagged with *what kind
  of evidence* proved it exists
- **Live metrics** per node (CPU, memory, network I/O), refreshed continuously

No agent is installed on the target. Nothing is instrumented. Everything is
derived from commands run over one SSH connection.

## 2. The rule that shapes the whole design

> **Declared is not observed. Connected is not communicating.**

Every edge carries two independent booleans:

| Field | Meaning |
|---|---|
| `declared` | Static configuration says A depends on B (a compose file, a config URL) |
| `observed` | Runtime evidence says A actually talked to B (a live TCP connection) |

An edge can be declared-but-never-observed (configured but idle), or
observed-but-never-declared (undocumented coupling — usually the interesting
one). They are never collapsed into a single "is connected" flag, and an edge
is **never** inferred from service names, image names, or shared membership of
a Docker network.

That last exclusion is deliberate and is enforced in code. See
`02-discovery/DiscoveryEngine.ts`:

```ts
const networkDependencies: Dependency[] = []; // disabled to prevent false-positive mesh from shared network
```

Every container in a compose stack usually shares one network, so
"same network" would produce a fully-connected mesh — technically true, and
completely useless. It's computed nowhere.

Each edge also carries `evidenceSources[]`, one of:
`compose`, `application-config`, `network-tcp`, `docker-network`, `http-log`,
`otel`, `application-log`.

---

## 3. End-to-end data flow

```
                        ┌────────────────────────────────┐
   remote host (EC2)    │  docker ps / inspect / stats    │
   no agent installed   │  cat compose + application.yml  │
                        │  /proc/net/tcp per container    │
                        └───────────────┬────────────────┘
                                        │  one persistent SSH connection
                                        ▼
  01-connection      ConnectionManager → SSHConnection → RemoteCommand
                     (per-command timeouts, output caps, sanitized paths)
                                        │
                     ┌──────────────────┴──────────────────┐
                     ▼                                     ▼
  02-discovery   DiscoveryEngine                    03-collection  MetricCollector
   (every 180s)   docker ps  ──► services            (every 5s)     docker stats ──► metrics
                  docker inspect ──► ports/IPs       (every 1s)     /proc/net/tcp ──► observed edges
                  compose depends_on ──► edges
                  application.yml URLs ──► edges
                     │                                     │
                     │  services[] + dependencies[]        │  samples[] + observedEdges[]
                     └──────────────────┬──────────────────┘
                                        ▼
  04-agent-loop            EndpointDiscoveryEngine (TargetAgent)
                       owns the SSH connection + all three timers,
                       translates collector output into a telemetry envelope
                                        │
                                        ▼
  05-graph-store                     GraphStore
                       handleTopologyDiscovered()  ← structure (nodes, declared edges)
                       ingestRemote()              ← metrics + observed edges
                       pruneStaleNodes()           ← removes what stopped reporting
                       getGraph()                  ← serialized to the UI
                                        │
                                        ▼
  07-client-layout                  useGraphData
                       groups nodes by project, lays out clusters
```

---

## 4. How nodes are built

`DiscoveryEngine.discoverServices()` (`02-discovery/DiscoveryEngine.ts`):

1. Run `docker ps --no-trunc --format '{{json .}}'` — **no filters**, so nothing
   is silently excluded.
2. For each container, run `docker inspect` for networks, IPs, mounts, restart
   count.
3. `deriveServiceName()` (`serviceIdentity.ts`) recovers the real service name:
   it prefers the `com.docker.compose.service` label, and falls back to
   stripping the project prefix and replica suffix off the container name —
   `docker-compose-manifests-ts-gateway-service-1` → `ts-gateway-service`.
4. `buildServiceId()` produces the stable identity: **`<targetId>:<name>`**,
   e.g. `train-ticket:ts-gateway-service`. This is the join key for everything
   downstream. It's derived, never random, so it survives restarts.
5. `classifyService()` assigns a type from image/name/port/label evidence, and
   records *which* evidence it used in `classificationEvidence[]` so a
   classification can be audited rather than trusted.

### Unmatched containers

`MetricCollector` matches each `docker stats` row to a discovered service by
container ID. If a container is running that discovery doesn't know about yet,
it is **not dropped** — it gets an ad-hoc id `<targetId>:unknown-<12 hex of
container id>` and a warning. Keeping unexplained evidence visible is
preferred over silently discarding it.

This is also why re-discovery matters: a container that restarts gets a **new
container ID**, so a discovery snapshot taken once at connect time goes stale
and its services start appearing as `unknown-*`. The agent re-runs discovery
every 180s to re-sync those IDs.

## 5. How edges are built

Three independent producers, merged by `mergeDependencies()`:

### a) Compose `depends_on` → `declared: true`, evidence `compose`

`parsers/composeDependsOn.ts`. Reads the compose file the containers were
actually started from (path taken from the
`com.docker.compose.project.config_files` label, not guessed).

### b) Config URL references → `declared: true`, evidence `application-config`

`parsers/applicationConfig.ts` — the highest-yield source in practice.

Many stacks declare no `depends_on` at all, yet every service knows its
collaborators' hostnames because they're written into its config. The parser
walks the whole YAML tree and pulls the host out of any `scheme://host[:port]`
value, resolving Spring-style `${VAR:default}` placeholders (the default is
what actually applies when the env var isn't set — the normal case in a compose
deployment):

```yaml
train-service:
  url: http://${TRAIN_SERVICE_HOST:ts-train-service}:${TRAIN_SERVICE_PORT:14567}
datasource:
  url: jdbc:mysql://${TRAVEL_MYSQL_HOST:ts-travel-mysql}:3306/db
```

→ hostnames `ts-train-service`, `ts-travel-mysql`.

It's generic on purpose: no key names are hardcoded (`url`, `server-addr`, … all
work), and nothing is project-specific. **An edge is only emitted if the
extracted hostname exactly matches a real discovered service.** A hostname that
matches nothing is discarded rather than turned into a phantom node.

> On one 17-service stack this produced 19 real edges where `depends_on`
> parsing alone produced zero.

### c) Live TCP connections → `observed: true`, evidence `network-tcp`

`MetricCollector.collectObservedEdges()` (`03-collection/MetricCollector.ts`):

1. Build an IP → service map from `docker inspect` network settings.
2. For each container, read its socket table from **inside its own network
   namespace**: `docker exec <id> sh -c 'cat /proc/net/tcp /proc/net/tcp6'`.
3. Keep sockets in state `01` (ESTABLISHED) and `06` (TIME_WAIT), decode the
   hex remote address, and map it back to a service.

Because this goes through `docker exec`, a container with no shell (scratch or
distroless images) yields no observed edges — it fails closed and is skipped,
rather than being reported as having no connections.

TIME_WAIT is included deliberately: it's the ~60s post-close linger state, so it
catches short request/response cycles that open and close between two 1-second
snapshots and would otherwise be invisible. The state that was actually seen is
recorded on the event — it isn't flattened into "connected".

## 6. Node and edge lifecycle in GraphStore

`05-graph-store/GraphStore.ts` is where it all merges. Two entry points:

- **`handleTopologyDiscovered(targetId, services, dependencies)`** — structure.
  Upserts nodes and declared edges, stamps `lastSeen`.
- **`ingestRemote(envelope)`** — telemetry. Attaches metrics, upserts observed
  edges, stamps `lastSeen`.

Everything is partitioned per target (`nodesByTarget`, `edgesByTarget`), so two
monitored systems never contaminate each other.

### Edge status is derived per cycle, never inherited

An edge's `status` comes only from edge-level evidence in the current cycle. A
node being under CPU/memory stress does **not** mark its edges degraded — that
would be asserting something about a link based on evidence about an endpoint.
Stale `degraded`/`failed` statuses are reset when no current edge-level evidence
supports them.

### Stale pruning

Nodes were originally only ever upserted, never removed, so a container that
disappeared (or changed ID) left a permanent ghost. `pruneStaleNodes()` now
removes any node not touched by discovery or telemetry within
`STALE_NODE_MS` (15 min), plus any edge referencing a removed node.

The threshold is deliberately longer than the 5-minute target-OFFLINE
threshold: on a resource-constrained host, SSH channel exhaustion can black out
*all* commands for several minutes, and a shorter window would wipe the graph
during a blackout the host recovers from on its own. Nodes loaded from disk are
stamped with a load-time baseline so they get a full grace window to be
reconfirmed rather than being judged instantly stale.

## 7. The agent loop and its three timers

`04-agent-loop/EndpointDiscoveryEngine.ts` (`TargetAgent`) owns one SSH
connection per target and runs:

| Timer | Interval | Work |
|---|---|---|
| `connectionTimer` | 1s | `/proc/net/tcp` scan → observed edges |
| `pollTimer` | 5s | `docker stats` + `inspect` → metrics |
| `rediscoveryTimer` | 180s | full `docker ps` + `inspect` → re-sync structure |

A separate connection (`adHocConnManager`) is used for on-demand log fetches so
they don't compete for channels with the polling loops.

Two failure-handling details that matter in practice:

- **A failed re-discovery never overwrites a good service list.** `docker ps`
  failing returns an empty list *without throwing*; blindly assigning that
  would wipe every matched service back to `unknown-*` until the next
  reconnect. The empty result is discarded and retried instead.
- **Re-discovery is expensive** (1 × `docker ps` + N × `docker inspect` in one
  burst) compared to the ambient 1s/5s commands. Running it too frequently on a
  loaded host caused `Channel open failure` errors across the *entire*
  connection, not just re-discovery — which is why the interval is 180s.

## 8. Known constraints

- All of this reads **container-level** signals. It shows that A holds a TCP
  connection to B, not which HTTP endpoint was called or how long it took.
  Request rates / latencies / error rates are `null` unless a real source
  provides them — they are never estimated.
- A service whose config names its dependencies gives good declared edges; one
  that discovers peers at runtime (service registry, DNS round-robin) will only
  ever show observed edges.
- Everything depends on the target host being responsive. On an overloaded box,
  `docker ps` times out (15s limit) and the graph simply reports what it last
  confirmed — it does not fill gaps with guesses.

---

## 9. File map

| Copy in this folder | Original path |
|---|---|
| `01-connection/Connection.ts` | `server/telemetry-platform/src/connection/Connection.ts` |
| `01-connection/ConnectionManager.ts` | `server/telemetry-platform/src/connection/ConnectionManager.ts` |
| `01-connection/SSHConnection.ts` | `server/telemetry-platform/src/connection/SSHConnection.ts` |
| `01-connection/RemoteCommand.ts` | `server/telemetry-platform/src/connection/RemoteCommand.ts` |
| `02-discovery/DiscoveryEngine.ts` | `server/telemetry-platform/src/discovery/DiscoveryEngine.ts` |
| `02-discovery/classifyService.ts` | `server/telemetry-platform/src/discovery/classifyService.ts` |
| `02-discovery/serviceIdentity.ts` | `server/telemetry-platform/src/discovery/serviceIdentity.ts` |
| `02-discovery/parsers/dockerPs.ts` | `server/telemetry-platform/src/discovery/parsers/dockerPs.ts` |
| `02-discovery/parsers/dockerInspect.ts` | `server/telemetry-platform/src/discovery/parsers/dockerInspect.ts` |
| `02-discovery/parsers/composeDependsOn.ts` | `server/telemetry-platform/src/discovery/parsers/composeDependsOn.ts` |
| `02-discovery/parsers/applicationConfig.ts` | `server/telemetry-platform/src/discovery/parsers/applicationConfig.ts` |
| `03-collection/MetricCollector.ts` | `server/telemetry-platform/src/collection/MetricCollector.ts` |
| `03-collection/parsers/dockerStats.ts` | `server/telemetry-platform/src/collection/parsers/dockerStats.ts` |
| `03-collection/units.ts` | `server/telemetry-platform/src/collection/units.ts` |
| `03-collection/cpu.ts` | `server/telemetry-platform/src/collection/cpu.ts` |
| `04-agent-loop/EndpointDiscoveryEngine.ts` | `server/discovery/EndpointDiscoveryEngine.ts` |
| `05-graph-store/GraphStore.ts` | `server/graph/GraphStore.ts` |
| `05-graph-store/GraphAnalytics.ts` | `server/graph/GraphAnalytics.ts` |
| `06-models/ServiceNode.ts` | `server/models/ServiceNode.ts` |
| `06-models/DependencyEdge.ts` | `server/models/DependencyEdge.ts` |
| `06-models/TelemetryEnvelope.ts` | `server/models/TelemetryEnvelope.ts` |
| `06-models/service.ts` | `server/telemetry-platform/src/types/service.ts` |
| `06-models/metrics.ts` | `server/telemetry-platform/src/types/metrics.ts` |
| `06-models/architecture.ts` | `server/telemetry-platform/src/types/architecture.ts` |
| `07-client-layout/useGraphData.ts` | `client/src/hooks/useGraphData.ts` |

## 10. Suggested reading order

1. `06-models/service.ts` — the `Service` / `Dependency` shapes, and the
   declared-vs-observed rule stated at the top of the file
2. `02-discovery/DiscoveryEngine.ts` — `discover()` is the whole structural
   pipeline in ~40 lines
3. `02-discovery/parsers/applicationConfig.ts` — small and self-contained
4. `03-collection/MetricCollector.ts` — `collectOnce()` then
   `collectObservedEdges()`
5. `05-graph-store/GraphStore.ts` — `handleTopologyDiscovered()`,
   `ingestRemote()`, `pruneStaleNodes()`
6. `04-agent-loop/EndpointDiscoveryEngine.ts` — how the timers drive it all

Dependencies used: `ssh2` (SSH transport), `js-yaml` (compose/config parsing).
Everything else is standard library.
